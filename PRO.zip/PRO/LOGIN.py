from tkinter import *
from tkinter import messagebox
import pymysql
loginwin=Tk()
loginwin.geometry('875x711')
loginwin.resizable(0,0)
loginwin.title("LOGIN")
bgImage=PhotoImage(file='BGIMGLatest.png')

bgLabel=Label(loginwin,image=bgImage)
bgLabel.place(x=0,y=0)

def forgetPassword():
    win = Toplevel()
    win.title("Change Password")
    win.geometry('853x663')
    win.resizable(0, 0)

    def changePassword():
        if(userEntry.get()=="" or passwordEntry.get()=="" or confirmEntry.get()==""):
            messagebox.showerror("NOTE","All Fields Must Be Filled..",parent=win) #To See On Our WINDOW Itself That's Why Parent Window
        elif(confirmEntry.get()!=passwordEntry.get()):
            messagebox.showerror("NOTE", "Password MisMatch..", parent=win)
        else:
            con = pymysql.connect(host="localhost", user="root", password="suku", port=4408,database="userdb")
            mycursor = con.cursor()  # This Variable Is Used For Executing Commands
            mycursor.execute("select *from users where username=%s",(userEntry.get()))
            row=mycursor.fetchone()
            if(row==None):
                messagebox.showinfo("Error","Incorrect Username..",parent=win)
            else:
                mycursor.execute("update users set password=%s where username=%s",(passwordEntry.get(),userEntry.get()))
                con.commit() #To Update Changes
                con.close()
                messagebox.showinfo("Success","Your Password Has Been Changed.. \n Login With New Password",parent=win)
                win.destroy()

    bgImg = PhotoImage(file='BGIMGForgetPassword.png')
    bgLabel = Label(win, image=bgImg)
    bgLabel.place(x=0, y=0)

    heading = Label(win, text="RESET PASSWORD", background="White", foreground='#3776ab',
                    font=("Lucida Sans", 24, "bold"))
    heading.place(x=380, y=100)

    userLabel = Label(win, text="USERNAME:", bg="White", fg="#3776ab", font=("Lucida Sans", 14, "bold"))
    userLabel.place(x=340, y=165)

    userEntry = Entry(win, width=32, bg="White", fg="#3776ab", font=("Lucida Sans", 14, "bold"), bd=0)
    userEntry.place(x=340, y=205)

    Frame(win, width=380, height=2, bg="#3776ab").place(x=340, y=228)  # Frame Is For Line

    passwordLabel = Label(win, text="NEW PASSWORD:", bg="White", fg="#3776ab", font=("Lucida Sans", 14, "bold"))
    passwordLabel.place(x=340, y=250)

    passwordEntry = Entry(win, width=32, bg="White", fg="#3776ab", font=("Lucida Sans", 14, "bold"), bd=0, show="*")
    passwordEntry.place(x=340, y=290)

    Frame(win, width=380, height=2, bg="#3776ab").place(x=340, y=317)

    confirmLabel = Label(win, text="CONFIRM PASSWORD:", bg="White", fg="#3776ab", font=("Lucida Sans", 14, "bold"))
    confirmLabel.place(x=340, y=340)

    confirmEntry = Entry(win, width=32, bg="White", fg="#3776ab", font=("Lucida Sans", 14, "bold"), bd=0, show="*")
    confirmEntry.place(x=340, y=380)

    Frame(win, width=380, height=2, bg="#3776ab").place(x=340, y=402)

    submitButton = Button(win, text="SUBMIT", bg="#3776ab", fg="White", font=("Lucida Sans", 14, "bold"), width=20,command=changePassword)
    submitButton.place(x=380, y=460)

    win.mainloop()
def loginUser():
    if(usernameEntry.get()=="" or passwordEntry.get()=="" or usernameEntry.get()=='Username' or passwordEntry.get()=='Password'):
        messagebox.showerror("Error","All Fields Must Be Filled..")
    else:
        try:
            con=pymysql.connect(host="localhost",user="root",password="suku",port=4408)
            mycursor=con.cursor() #This Variable Is Used For Executing Commands
        except:
            messagebox.showerror("Connection Error","Database Connectivity Issue.. ")

        mycursor.execute('use userdb')
        q='select *from users where username=%s and password=%s'
        #To Check Whether Username And Password Exists Or Not
        mycursor.execute(q,(usernameEntry.get(),passwordEntry.get()))

        row=mycursor.fetchone()
        if row==None: #If No Rows Are Available Then Show The Error Message
            messagebox.showerror("Error", "Invalid Username Or Password..")
        else:
            messagebox.showinfo("Welcome","Login Successful.. Thank You..")
            loginwin.destroy()
            import GameLevel1
heading=Label(loginwin,text="USER LOGIN",background="White",foreground='#3776ab',font=("Lucida Sans",20,"bold"))
heading.place(x=480,y=100)

usernameEntry=Entry(loginwin,width=20,font=("Georgia",12,"bold"),bd=0,fg='#3776ab')
usernameEntry.place(x=450,y=200)
usernameEntry.insert(0,"Username")

def user_enter(event):
    if(usernameEntry.get()=='Username'):
        usernameEntry.delete(0,END)
usernameEntry.bind('<FocusIn>',user_enter) #Gets Triggered When Entry Widget Gains Focus

userFrame=Frame(loginwin,width=200,height=2,bg='#3776ab')
userFrame.place(x=450,y=220)

passwordEntry=Entry(loginwin,width=20,font=("Georgia",12,"bold"),bd=0,fg='#3776ab')
passwordEntry.place(x=450,y=260)
passwordEntry.insert(0,"Password")

def password_enter(event):
    if(passwordEntry.get()=='Password'):
        passwordEntry.delete(0,END)
passwordEntry.bind('<FocusIn>',password_enter) #Gets Triggered When Entry Widget Gains Focus

passwordFrame=Frame(loginwin,width=200,height=2,bg='#3776ab')
passwordFrame.place(x=450,y=280)

def hide():
    openeye.config(file="CloseEyeImg.png")
    passwordEntry.config(show="*")
    openEyeButton.config(command=show)
openeye=PhotoImage(file="OpenEyeImg.png")
openEyeButton=Button(loginwin,image=openeye,height=18,width=20,bd=0,bg="White",command=hide)
openEyeButton.place(x=620,y=260)

def show():
    openeye.config(file="OpenEyeImg.png")
    passwordEntry.config(show='')
    openEyeButton.config(command=hide)

forgetButton=Button(loginwin,text="Forget Password?",bd=0,bg='White',activeforeground='#3776ab',
                    font=("Georgia",9,"bold"),cursor='hand2',command=forgetPassword)
forgetButton.place(x=540,y=305)

loginButton=Button(loginwin,text="Login",bd=0,bg='#ff4500',activebackground='White',activeforeground='#3776ab',
                    font=("Georgia",9,"bold"),width=25,height=2,cursor='hand2',command=loginUser)
loginButton.place(x=460,y=380)

l1=Label(text="-------------------OR-------------------",bd=0,bg='White',fg='#3776ab',
                    font=("Georgia",9,"bold"))
l1.place(x=460,y=425)

signupLabel=Label(loginwin,text="Don't Have An Account?",bd=0,bg='#ff4500',activebackground='White',activeforeground='#3776ab',
                    font=("Georgia",9,"bold"))
signupLabel.place(x=440,y=485)

def registerPage():
    loginwin.destroy()
    import REGISTER
accountButton=Button(loginwin,text="Create A New Account",bd=0,bg='White',fg='blue',
                    font=("Georgia",9,"bold underline"),cursor='hand2',activeforeground="blue",command=registerPage)
accountButton.place(x=600,y=485)

loginwin.mainloop()