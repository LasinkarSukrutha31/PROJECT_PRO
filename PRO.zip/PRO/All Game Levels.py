from tkinter import *
from PIL import ImageTk,Image
#ROOT
root=Tk()
root.title("ALL LEVELS")
root.geometry("800x700")
root.resizable(0,0)

imgO=Image.open("D:\\PythonProject2\\PRO\\LevelsBG - Copy.jpg")
bgIMG=ImageTk.PhotoImage(imgO)

def GL1():

    root.destroy()
    import GameLevel1
def GL2():


    root.destroy()
    import GameLevel2
    
def GL3():

    root.destroy()
    import GL3

def PM():
    root.destroy()
    import PM

bgLabel=Label(root,image=bgIMG).place(x=0,y=0)
l1=Label(text='GAME LEVELS',width=22,bg='Blue',font=("Georgia",17,"bold"),fg='White',justify='center')
l1.place(x=240,y=140)

b1=Button(root,text='Level 1',width=14,bg='Black',font=("Georgia",17,"bold"),fg='White',command=GL1,justify='center')
b1.place(x=320,y=200)

b2=Button(root,text='Level 2',width=14,bg='Orange',font=("Georgia",17,"bold"),fg='White',command=GL2,justify='center')
b2.place(x=320,y=260)

b3=Button(root,text='Level 3',width=14,bg='Red',font=("Georgia",17,"bold"),fg='White',command=GL3,justify='center')
b3.place(x=320,y=320)


b4=Button(root,text='Practice Myself',width=14,bg='Purple',font=("Georgia",17,"bold"),fg='White',command=PM)
b4.place(x=320,y=380)


root.mainloop()