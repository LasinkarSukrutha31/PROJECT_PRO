import random
from tkinter import *
from tkinter import messagebox
#ROOT
root=Tk()
root.title("MASTER TYPING GAME LEVEL 1")
root.geometry("850x700")
root.resizable(0,0)
root.config(bg="Powder Blue")
#VARIABLES
score=0
timer=60
count=0
sliderwords=''
miss=0

words=['Apple','Banana','Custard Apple','Pine Apple','Grapes','Kiwi','Dry Fruits','Mango','Strawberry','Fan','Door','Mobile',
       'Charger','PyCharm','Plotter','algorithm','application','backup','bit','blog','boot','clip board','compile',
       'dashboard','database','email','encryption','gigabyte','graphics','Hard disk','Home page','Internet',
       'Java','LAN','Megabyte','Online','PDF','Processor','RAM','Server','URL','Virus','Wi-Fi','Zip']
#FUNCTIONS
def l1Slider():
    global count, sliderwords
    text="Welcome To Master Typing Easy Level"
    if(count>=len(text)):
        count=0
        sliderwords=''
    sliderwords+=text[count]
    count+=1
    l1.configure(text=sliderwords)
    l1.after(150,l1Slider)

def time():
    global timer,score,miss
    if(timer<=11):
        timerLabelCount.configure(fg="red")
    else:
        timerLabelCount.configure(fg=col[no])
    if(timer>0):
        timer=timer-1
        timerLabelCount.configure(text=timer)
        timerLabelCount.after(1000,time)
    else:
        l2.configure(text="Hit={} | Miss={} | Total Score={}".format(score,miss,(score-miss)))
        msg=messagebox.askretrycancel("Confirmation","To Play Again Click On Retry..")
        if(msg==True):
            score=0
            miss=0
            timer=60
            wordLabel.configure(text=words[no])
            scoreLabelCount.configure(text=score)
            timerLabelCount.configure(text=timer)
        else:
            wordEntry.delete(0,END)
            wordEntry.configure(state=DISABLED)
def startGame(event):
    global score,miss
    if(timer==60):
        time()
    l2.configure(text=" ")
    if(wordEntry.get()==wordLabel['text']):
        score=score+1
        scoreLabelCount.configure(text=score)
    else:
        miss=miss+1
        #print("Miss:",miss)
    no1=random.randint(0, len(words)-1)
    wordLabel.config(text=words[no1])
    wordEntry.delete(0, END)
#GUI WIDGETS
l1=Label(root,text=" ",font=("Georgia",25,"bold"),bg="Powder Blue",fg="red",width=31,justify='left')
l1.place(x=150,y=10)
l1Slider()

col=['Red','Green','Violet','Brown','Black','Orange','Purple','Blue']
no=random.randint(0,len(col)-1)

no1=random.randint(0, len(words)-1)

wordLabel=Label(root,text=words[no1],font=("Georgia",25,"bold"),fg=col[no],bg='Powder Blue')
wordLabel.place(x=350,y=200)

wordEntry=Entry(root,border=10,fg=col[no],width=15,font=("Georgia",22,"bold"),justify='center')
wordEntry.place(x=340,y=274)
wordEntry.focus_set()

col=['Red','Green','Brown','Black','Blue','Violet','Purple','Orange']
no=random.randint(0,len(col)-1)
scoreLabel=Label(root,text="Your Score:",fg=col[no],font=("Georgia",25,"bold italic"),bg="Powder Blue")
scoreLabel.place(x=100,y=100)

scoreLabelCount=Label(root,text="0",fg=col[no],font=("Georgia",25,"bold italic"),bg="Powder Blue")
scoreLabelCount.place(x=150,y=150)

col=['Red','Green','Brown','Black','Blue','Orange','Purple','Violet']
no=random.randint(0,len(col)-1)
timerLabel=Label(root,text="Time Left:",fg=col[no],font=("Georgia",25,"bold italic"),bg="Powder Blue")
timerLabel.place(x=620,y=100)

timerLabelCount=Label(root,text="60",fg=col[no],font=("Georgia",25,"bold italic"),bg="Powder Blue")
timerLabelCount.place(x=680,y=150)

l2=Label(root,text="Type Word And Press Enter",font=("Georgia",25,"bold italic"),bg="Powder Blue",fg='Dark Grey')
l2.place(x=250,y=400)
root.bind('<Return>',startGame) #To Handle Event/Generate Event

root.mainloop()