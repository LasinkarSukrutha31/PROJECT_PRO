from tkinter import *
win=Tk()
win.title("Change Password")
win.geometry('853x663')
win.resizable(0,0)

bgImg=PhotoImage(file='BGIMGForgetPassword.png')
bgLabel=Label(win,image=bgImg)
bgLabel.place(x=0,y=0)

heading = Label(win, text="RESET PASSWORD", background="White", foreground='#3776ab',
font=("Lucida Sans", 20, "bold"))
heading.place(x=380, y=100)

userLabel=Label(win,text="USERNAME:",bg="White",fg="#3776ab",font=("Lucida Sans",14,"bold"))
userLabel.place(x=340, y=165)

userEntry=Entry(win,width=32,bg="White",fg="#3776ab",font=("Lucida Sans",14,"bold"),bd=0)
userEntry.place(x=340, y=205)

Frame(win,width=380,height=2,bg="#3776ab").place(x=340,y=228) #Frame Is For Line

passwordLabel=Label(win,text="NEW PASSWORD:",bg="White",fg="#3776ab",font=("Lucida Sans",14,"bold"))
passwordLabel.place(x=340, y=250)

passwordEntry=Entry(win,width=32,bg="White",fg="#3776ab",font=("Lucida Sans",14,"bold"),bd=0,show="*")
passwordEntry.place(x=340, y=290)

Frame(win,width=380,height=2,bg="#3776ab").place(x=340,y=317)

confirmLabel=Label(win,text="CONFIRM PASSWORD:",bg="White",fg="#3776ab",font=("Lucida Sans",14,"bold"))
confirmLabel.place(x=340, y=340)

confirmEntry=Entry(win,width=32,bg="White",fg="#3776ab",font=("Lucida Sans",14,"bold"),bd=0,show="*")
confirmEntry.place(x=340, y=380)

Frame(win,width=380,height=2,bg="#3776ab").place(x=340,y=402)

submitButton=Button(win,text="SUBMIT",bg="#3776ab",fg="White",font=("Lucida Sans",14,"bold"),width=20)
submitButton.place(x=380, y=460)

win.mainloop()