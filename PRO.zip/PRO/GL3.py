from tkinter import *
import random
import ttkthemes
from tkinter import ttk
from time import sleep
import threading
from tkinter import messagebox

root=ttkthemes.ThemedTk() #ttk->Themed Tk
root.get_themes()
root.set_theme('radiance')
root.geometry("1000x700")
root.title("TYPING SPEED TEST")
root.resizable(0,0)
#img=PhotoImage(file="DesktopImage.png")
#root.iconphoto(True,img)

totalTime=60
time=0
wrongwords=0
elapsedTimeMinutes=0
def startTimer():
    startButton.config(state=DISABLED)
    global time #The Updated Value Will Be And Can Be Accessed Through Out The Program
    textArea.config(state=NORMAL)
    textArea.focus() #For Blinking

    #Elapse Timer
    #The Time That You Set
    for time in range(1,61):
        elapsedTimerLabel.config(text=time)
        remainingTime=totalTime-time
        remainingTimerLabel.config(text=remainingTime)
        sleep(1)
        root.update()

    textArea.config(state=DISABLED)
    resetButton.config(state=NORMAL)

#Count Number Of Words/Wrong Words
def count():
    global wrongwords

    while(time!=totalTime):
        while(time==59):
            messagebox.showinfo("Time's Up","Time's Up..")
        enteredParagraph=textArea.get(1.0,END).split()  #1.0 means Input Should Be Read From Line One Character Zero(i.e First Character) To End
        totalwords=len(enteredParagraph)

    TotalWordsCountLabel.config(text=totalwords)#config() Used To Access The Objects Attributes After Initialization

    paraWordList=label_paragraph['text'].split()
    for pair in list(zip(paraWordList,enteredParagraph)): #zip->2
        # Arguments It Takes One Word From ParagraphList And One Word From The Entered Paragraph It Stores In The Tuples
        if(pair[0]!=pair[1]):
            wrongwords+=1;
    WrongWordsCountLabel.config(text=wrongwords)

    elapsedTimeMinutes=time/60
    wpm= (totalwords - wrongwords) / elapsedTimeMinutes #Counting Correct Number Of Words #Ex:Suppose Total Words=13 Wrong Words=9
                                                        #WPM=4.0
    WPMCountLabel.config(text=wpm)
    wpm1= totalwords / elapsedTimeMinutes #Counting Total Number Of Words
    accuracy=wpm/wpm1*100
    accuracy=round(accuracy)                #4.0/13*100=31%
    accuracyPercentLabel.config(text=str(accuracy)+"%")

    #MultiThreading To Execute Concurrently For The startTimer() & count()
def start():
    messagebox.showinfo("Time's On", "Let's Start Typing..")
    t1=threading.Thread(target=startTimer)
    t1.start()
    t2=threading.Thread(target=count)
    t2.start()

def reset():
    global time,elapsedTimeMinutes
    time=0
    elapsedTimeMinutes=0
    startButton.config(state=NORMAL)
    resetButton.config(state=DISABLED)
    textArea.config(state=NORMAL)
    textArea.delete(1.0,END)
    textArea.config(state=DISABLED)

    elapsedTimerLabel.config(text="0")
    remainingTimerLabel.config(text="0")
    WPMCountLabel.config(text="0")
    TotalWordsCountLabel.config(text="0")
    WrongWordsCountLabel.config(text="0")
    accuracyPercentLabel.config(text="0")
    totalTime = 60
    time = 0
    wrongwords = 0
    elapsedTimeMinutes = 0

mainFrame=Frame(root,bd=4)
mainFrame.grid()

titleFrame=Frame(mainFrame,bg="Orange")
titleFrame.grid()

titleLabel=Label(titleFrame,text="MASTER TYPING",font=("Algerian",20,"bold"),bg="Orange",fg="Black",width=54,bd=10)
titleLabel.grid()

paragraphFrame=Frame(mainFrame)
paragraphFrame.grid(row=1,column=0)
paragraphList=['The internet is the most creative and interactive innovation globally. '
                'It is the most helpful technology to share information from one part to the other part of the world. '
                'We are just a click away from knowing about the whole world. After the invention of the internet, '
                'it feels as if the world has narrowed down, and we are no more away from our close ones. Because of the internet, '
                'all official work and education could continue even during the pandemic. ',
                'Games and sports are an essential part of the life of individuals from all walks of life. '
                'We are mostly introduced to various sports and games from our school life.'
                ' We involve ourselves in different kinds of sports, and some children also choose their career options from these sports. '
                'Some people prefer indoor games, and some choose outdoor sports. Indoor games may include ludo, chess, table tennis, board games, etc., '
                'and outdoor games include cricket, basketball, football, etc.'
                ' Board games include various types of games like UNO, Chinese Checker, and other card games. ',
                'Chess is an immensely complex game which is the basis for its enjoyment. '
                'It includes many unique pieces with their own specific moving patterns. '
                'Chess also has numerous rules and scenarios which keep the game fresh and interesting.'
                ' Due to the various moving patterns and rules, it leads to a particularly complex game. '
                'Although it is complicated, it becomes easier with practice and experience.'
                ' Keep reading and you will be a chess master in no time.',
                'Python is a popular programming language. It was created by Guido van Rossum, and released in 1991.'
                'Python can be used on a server to create web applications.'
               'Python can be used alongside software to create workflows.'
               'Python can connect to database systems. It can also read and modify files.'
               'Python can be used to handle big data and perform complex mathematics.',
               'Python can be used for rapid prototyping, or for production-ready software development.'
               'Python works on different platforms (Windows, Mac, Linux, Raspberry Pi, etc).']
p=random.randint(0,len(paragraphList)-1)
label_paragraph=Label(paragraphFrame,text=paragraphList[p],wraplength=920,justify=LEFT,font=("Courier",14,"bold"))
label_paragraph.grid(row=0,column=0)

textAreaFrame=Frame(mainFrame)
textAreaFrame.grid(row=2,column=0)

textArea=Text(textAreaFrame,font=('Courier',12,'bold'),width=90,height=7,bd=4,wrap='word',state=DISABLED)
textArea.grid()

frameOutput=Frame(mainFrame)
frameOutput.grid(row=3,column=0)

elapsedTimeLabel=Label(frameOutput,text="Elapsed",font=('Courier',12,'bold'),fg="Red")
elapsedTimeLabel.grid(row=0,column=0,padx=5)

elapsedTimerLabel=Label(frameOutput,text="0",font=('Courier',12,'bold'),fg="Black")
elapsedTimerLabel.grid(row=0,column=1,padx=5)

remainingTimeLabel=Label(frameOutput,text="Remaining Time",font=('Courier',12,'bold'),fg="Red")
remainingTimeLabel.grid(row=0,column=2,padx=5)

remainingTimerLabel=Label(frameOutput,text="60",font=('Courier',12,'bold'),fg="Black")
remainingTimerLabel.grid(row=0,column=3,padx=5)

WPMLabel=Label(frameOutput,text="WPM",font=('Courier',12,'bold'),fg="Red")
WPMLabel.grid(row=0,column=4,padx=5)

WPMCountLabel=Label(frameOutput,text="0",font=('Courier',12,'bold'),fg="Black")
WPMCountLabel.grid(row=0,column=5)

TotalWordsLabel=Label(frameOutput,text="Total Words",font=('Courier',12,'bold'),fg="Red")
TotalWordsLabel.grid(row=0,column=6,padx=5)

TotalWordsCountLabel=Label(frameOutput,text="0",font=('Courier',12,'bold'),fg="Black")
TotalWordsCountLabel.grid(row=0,column=7,padx=5)

WrongWordsLabel=Label(frameOutput,text="Wrong Words",font=('Courier',12,'bold'),fg="Red")
WrongWordsLabel.grid(row=0,column=8,padx=5)

WrongWordsCountLabel=Label(frameOutput,text="0",font=('Courier',12,'bold'),fg="Black")
WrongWordsCountLabel.grid(row=0,column=9,padx=5)

accuracyLabel=Label(frameOutput,text="Accuracy",font=('Courier',12,'bold'),fg="Red")
accuracyLabel.grid(row=0,column=10,padx=5)

accuracyPercentLabel=Label(frameOutput,text="0",font=('Courier',12,'bold'),fg="Black")
accuracyPercentLabel.grid(row=0,column=11,padx=5)

buttonsFrame=Frame(mainFrame)
buttonsFrame.grid(row=4,column=0)

startButton=ttk.Button(buttonsFrame,text="Start",command=start)
startButton.grid(row=0,column=0,padx=10)

resetButton=ttk.Button(buttonsFrame,text="Reset",state=DISABLED,command=reset)
resetButton.grid(row=0,column=1,padx=10)

exitButton=ttk.Button(buttonsFrame,text="Exit",command=root.destroy)
exitButton.grid(row=0,column=2,padx=10)

keyboardFrame=Frame(mainFrame)
keyboardFrame.grid(row=5,column=0)
frame1To0=Frame(keyboardFrame)
frame1To0.grid(row=0,column=0,pady=4)

l1=Label(frame1To0,text="1",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l1.grid(row=0,column=0,padx=5)
l2=Label(frame1To0,text="2",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l2.grid(row=0,column=1,padx=5)
l3=Label(frame1To0,text="3",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l3.grid(row=0,column=2,padx=5)
l4=Label(frame1To0,text="4",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l4.grid(row=0,column=3,padx=5)
l5=Label(frame1To0,text="5",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l5.grid(row=0,column=4,padx=5)
l6=Label(frame1To0,text="6",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l6.grid(row=0,column=5,padx=5)
l7=Label(frame1To0,text="7",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l7.grid(row=0,column=6,padx=5)
l8=Label(frame1To0,text="8",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l8.grid(row=0,column=7,padx=5)
l9=Label(frame1To0,text="9",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l9.grid(row=0,column=8,padx=5)
l0=Label(frame1To0,text="0",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l0.grid(row=0,column=9,padx=5)
frameQToP=Frame(keyboardFrame)
frameQToP.grid(row=1,column=0,pady=4)
lQ=Label(frameQToP,text="Q",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lQ.grid(row=0,column=0,padx=5)
lW=Label(frameQToP,text="W",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lW.grid(row=0,column=1,padx=5)
lE=Label(frameQToP,text="E",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lE.grid(row=0,column=2,padx=5)
lR=Label(frameQToP,text="R",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lR.grid(row=0,column=3,padx=5)
lT=Label(frameQToP,text="T",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lT.grid(row=0,column=4,padx=5)
lY=Label(frameQToP,text="Y",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lY.grid(row=0,column=5,padx=5)
lU=Label(frameQToP,text="U",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lU.grid(row=0,column=6,padx=5)
lI=Label(frameQToP,text="I",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lI.grid(row=0,column=7,padx=5)
lO=Label(frameQToP,text="O",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lO.grid(row=0,column=8,padx=5)
lP=Label(frameQToP,text="P",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lP.grid(row=0,column=9,padx=5)

frameAToL=Frame(keyboardFrame)
frameAToL.grid(row=2,column=0)
lA=Label(frameAToL,text="A",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lA.grid(row=0,column=0,padx=5)
lS=Label(frameAToL,text="S",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lS.grid(row=0,column=1,padx=5)
lD=Label(frameAToL,text="D",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lD.grid(row=0,column=2,padx=5)
lF=Label(frameAToL,text="F",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lF.grid(row=0,column=3,padx=5)
lG=Label(frameAToL,text="G",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lG.grid(row=0,column=4,padx=5)
lH=Label(frameAToL,text="H",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lH.grid(row=0,column=5,padx=5)
lJ=Label(frameAToL,text="J",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lJ.grid(row=0,column=6,padx=5)
lK=Label(frameAToL,text="K",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lK.grid(row=0,column=7,padx=5)
lL=Label(frameAToL,text="L",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lL.grid(row=0,column=8,padx=5)

frameZToM=Frame(keyboardFrame)
frameZToM.grid(row=3,column=0,pady=4)
lZ=Label(frameZToM,text="Z",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lZ.grid(row=0,column=0,padx=5)
lX=Label(frameZToM,text="X",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lX.grid(row=0,column=1,padx=5)
lC=Label(frameZToM,text="C",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lC.grid(row=0,column=2,padx=5)
lV=Label(frameZToM,text="V",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lV.grid(row=0,column=3,padx=5)
lB=Label(frameZToM,text="B",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lB.grid(row=0,column=4,padx=5)
lN=Label(frameZToM,text="N",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lN.grid(row=0,column=5,padx=5)
lM=Label(frameZToM,text="M",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lM.grid(row=0,column=6,padx=5)

spaceFrame=Frame(keyboardFrame)
spaceFrame.grid(row=4,column=0)

spaceLabel=Label(spaceFrame,bg="Black",fg="White",font=("Courier",10,"bold"),width=40,height=2,bd=10,relief=GROOVE)
spaceLabel.grid(row=0,column=0)

labelNumbers=[l1,l2,l3,l4,l5,l6,l7,l8,l9,l0]
labelsAlphabets=[lA,lB,lC,lD,lE,lF,lG,lH,lI,lJ,lK,lL,lM,lN,lO,lP,lQ,lR,lS,lT,lU,lV,lW,lX,lY,lZ]
labelspace=[spaceLabel]

colors1=['Blue','Red','Green','Pink','Orange','Brown']
def changeBGColor(label):
        col = random.randint(0, len(colors1)-1)
        label.config(bg=(colors1[col]))
        label.after(200,lambda :label.config(bg='black'))
bindingNumbers=['1','2','3','4','5','6','7','8','9','0']
bindingSmallAlphabets=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
bindingCapitalAlphabets=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

for numbers in range(0,len(bindingNumbers)):
    root.bind(bindingNumbers[numbers],lambda event,label=labelNumbers[numbers]:changeBGColor(label))

for smallAlphabets in range(0,len(bindingSmallAlphabets)):
    root.bind(bindingSmallAlphabets[smallAlphabets],lambda event,label=labelsAlphabets[smallAlphabets]:changeBGColor(label))

for capitalAlphabets in range(0,len(bindingCapitalAlphabets)):
    root.bind(bindingCapitalAlphabets[capitalAlphabets],lambda event,label=labelsAlphabets[capitalAlphabets]:changeBGColor(label))

root.bind('<space>', lambda event: changeBGColor(labelspace[0]))


root.mainloop()