from tkinter import *
from tkinter import messagebox
import pymysql
registerwin=Tk()
registerwin.geometry('862x697')
registerwin.resizable(0,0)
registerwin.title("REGISTER")

bgImage=PhotoImage(file='BGIMG1.png')
bgLabel=Label(registerwin,image=bgImage)
bgLabel.place(x=0,y=0)

def loginPage():
    registerwin.destroy()
    import LOGIN

def clear():
    userEntry.delete(0, END)
    emailEntry.delete(0, END)
    passwordEntry.delete(0, END)
    confirmEntry.delete(0, END)
    checkVar.set(0)

def conDataBase():
    if(userEntry.get()=="" or emailEntry.get()=="" or passwordEntry.get()=="" or confirmEntry.get()==""):
        messagebox.showerror("NOTE","All Fields Must Be Filled..")
    elif(passwordEntry.get() !=confirmEntry.get()):
        messagebox.showerror("NOTE","Password MisMatch..")
    elif(checkVar.get())==0:
        messagebox.showerror("NOTE","Please Accept The Terms And Conditions..")
    else:
        try:
            con=pymysql.connect(host="localhost",user="root",password="suku",port=4408)
            mycursor=con.cursor()
        except:
            messagebox.showerror("Connection Error","Database Connectivity Issue.. ")
            return
        try:
            #If DataBase Is Not Created..
            q1='create database userdb' #Query 1
            mycursor.execute(q1)
            q2='use userdb' #Query 2
            mycursor.execute(q2)
            q3='create table users(id int auto_increment primary key not null,username varchar(100),email varchar(100),password varchar(20))'
            mycursor.execute(q3)
        except:
            #If DataBase Is Created Then Will Use use userdb
            mycursor.execute('use userdb')

        q5='Select *from users where username=%s'
        mycursor.execute(q5,(userEntry.get()))
        #To Check Whether The Username Exists Or Not..
        row=mycursor.fetchone()
        if(row!=None): #If Username Doesn't Match With Any Of The Users(None Users No Users)
            messagebox.showerror("NOTE", "User Name Already Exists..") #If Row Is Available then It Shows The Error..
        else: #If It Doesn't Match WIth Anyone Of The Row(row==None)
            q4='insert into users(username,email,password) values(%s,%s,%s)'
            mycursor.execute(q4,(userEntry.get(),emailEntry.get(),passwordEntry.get()))

            con.commit() #To Update The Changes(Example Insert)
                        #mycursor Variable To Execute
            con.close()
            messagebox.showinfo("Success","Registration Successful..")

            clear()
            loginPage()


#padx,pady Horizontal,Vertical
frame=Frame(registerwin,bg="White")
frame.place(x=200,y=90) #To Add All Widgets,It Increases Automatically

heading=Label(frame,text="CREATE AN ACCOUNT",bg='Purple',fg='Orange',font=("Lucida Sans",20,"bold"),width=32)
heading.grid(row=0,column=0,padx=10,pady=10) #Easy To Use


userLabel=Label(frame,text="USERNAME:",bg="Purple",fg="Orange",font=("Lucida Sans",14,"bold"))
userLabel.grid(row=1,column=0,sticky="w",pady=5,padx=50)

userEntry=Entry(frame,width=35,bg="White",fg="#3776ab",font=("Lucida Sans",14,"bold"),bd=2)
userEntry.grid(row=2,column=0,sticky="w",pady=5,padx=50)

emailLabel=Label(frame,text="EMAIL:",bg="Purple",fg="Orange",font=("Lucida Sans",14,"bold"))
emailLabel.grid(row=3,column=0,sticky="w",padx=50,pady=5)

emailEntry=Entry(frame,width=35,bg="White",fg="#3776ab",font=("Lucida Sans",14,"bold"),bd=2)
emailEntry.grid(row=4,column=0,sticky="w",padx=50,pady=5)

passwordLabel=Label(frame,text="PASSWORD:",bg="Purple",fg="Orange",font=("Lucida Sans",14,"bold"))
passwordLabel.grid(row=5,column=0,sticky="w",padx=50,pady=5)

passwordEntry=Entry(frame,width=35,bg="White",fg="#3776ab",font=("Lucida Sans",14,"bold"),bd=2,show="*")
passwordEntry.grid(row=6,column=0,sticky="w",padx=50,pady=5)

confirmLabel=Label(frame,text="CONFIRM PASSWORD:",bg="Purple",fg="Orange",font=("Lucida Sans",14,"bold"))
confirmLabel.grid(row=7,column=0,padx=50,sticky="w",pady=5)

confirmEntry=Entry(frame,width=35,bg="White",fg="#3776ab",font=("Lucida Sans",14,"bold"),bd=2,show="*")
confirmEntry.grid(row=8,column=0,sticky="w",pady=5,padx=50)

checkVar=IntVar()
tac=Checkbutton(frame,text="I Agree Above The Terms A Conditions",bg="Orange",fg="#3776ab",font=("Lucida Sans",12,"bold"),bd=2,variable=checkVar)
tac.grid(row=9,column=0,pady=5,sticky="w",padx=50)

submitButton=Button(frame,text="SignUp",bg="Purple",fg="Orange",font=("Lucida Sans",14,"bold"),width=20,command=conDataBase)
submitButton.grid(row=10,column=0,pady=20,sticky="n",padx=50)

l1=Label(frame,text="Don't Have An Account?",bg="White",fg="Purple",font=("Lucida Sans",14,"bold"))
l1.grid(row=11,column=0,pady=5,sticky="w",padx=47)

loginButton=Button(frame,text="Login",bg="White",fg="Blue",font=("Lucida Sans",9,"bold underline")
                   ,activeforeground="Blue",bd=0,cursor="hand2",command=loginPage)
loginButton.place(x=290,y=490)
registerwin.mainloop()