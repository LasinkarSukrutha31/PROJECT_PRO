from tkinter import *
import random
root=Tk()
root.title("PRACTICE MYSELF")
root.geometry("800x700")
root.resizable(0,0)

l1=Label(text="PRACTICE UR SELF",font='Lucida')
l1.grid(row=2,column=2)

textArea=Text(font='Courier',width=60,height=14,border=14)
textArea.grid(row=8,column=2)



keyboardFrame=Frame(root)
keyboardFrame.grid(row=12,column=2)
frame1To0=Frame(keyboardFrame)
frame1To0.grid(row=0,column=0,pady=4)

l1=Label(frame1To0,text="1",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l1.grid(row=0,column=0,padx=5)
l2=Label(frame1To0,text="2",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l2.grid(row=0,column=1,padx=5)
l3=Label(frame1To0,text="3",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l3.grid(row=0,column=2,padx=5)
l4=Label(frame1To0,text="4",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l4.grid(row=0,column=3,padx=5)
l5=Label(frame1To0,text="5",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l5.grid(row=0,column=4,padx=5)
l6=Label(frame1To0,text="6",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l6.grid(row=0,column=5,padx=5)
l7=Label(frame1To0,text="7",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l7.grid(row=0,column=6,padx=5)
l8=Label(frame1To0,text="8",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l8.grid(row=0,column=7,padx=5)
l9=Label(frame1To0,text="9",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l9.grid(row=0,column=8,padx=5)
l0=Label(frame1To0,text="0",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
l0.grid(row=0,column=9,padx=5)
frameQToP=Frame(keyboardFrame)
frameQToP.grid(row=1,column=0,pady=4)
lQ=Label(frameQToP,text="Q",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lQ.grid(row=0,column=0,padx=5)
lW=Label(frameQToP,text="W",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lW.grid(row=0,column=1,padx=5)
lE=Label(frameQToP,text="E",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lE.grid(row=0,column=2,padx=5)
lR=Label(frameQToP,text="R",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lR.grid(row=0,column=3,padx=5)
lT=Label(frameQToP,text="T",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lT.grid(row=0,column=4,padx=5)
lY=Label(frameQToP,text="Y",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lY.grid(row=0,column=5,padx=5)
lU=Label(frameQToP,text="U",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lU.grid(row=0,column=6,padx=5)
lI=Label(frameQToP,text="I",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lI.grid(row=0,column=7,padx=5)
lO=Label(frameQToP,text="O",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lO.grid(row=0,column=8,padx=5)
lP=Label(frameQToP,text="P",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lP.grid(row=0,column=9,padx=5)

frameAToL=Frame(keyboardFrame)
frameAToL.grid(row=2,column=0)
lA=Label(frameAToL,text="A",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lA.grid(row=0,column=0,padx=5)
lS=Label(frameAToL,text="S",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lS.grid(row=0,column=1,padx=5)
lD=Label(frameAToL,text="D",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lD.grid(row=0,column=2,padx=5)
lF=Label(frameAToL,text="F",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lF.grid(row=0,column=3,padx=5)
lG=Label(frameAToL,text="G",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lG.grid(row=0,column=4,padx=5)
lH=Label(frameAToL,text="H",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lH.grid(row=0,column=5,padx=5)
lJ=Label(frameAToL,text="J",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lJ.grid(row=0,column=6,padx=5)
lK=Label(frameAToL,text="K",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lK.grid(row=0,column=7,padx=5)
lL=Label(frameAToL,text="L",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lL.grid(row=0,column=8,padx=5)

frameZToM=Frame(keyboardFrame)
frameZToM.grid(row=3,column=0,pady=4)
lZ=Label(frameZToM,text="Z",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lZ.grid(row=0,column=0,padx=5)
lX=Label(frameZToM,text="X",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lX.grid(row=0,column=1,padx=5)
lC=Label(frameZToM,text="C",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lC.grid(row=0,column=2,padx=5)
lV=Label(frameZToM,text="V",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lV.grid(row=0,column=3,padx=5)
lB=Label(frameZToM,text="B",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lB.grid(row=0,column=4,padx=5)
lN=Label(frameZToM,text="N",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lN.grid(row=0,column=5,padx=5)
lM=Label(frameZToM,text="M",bg="Black",fg="White",font=("Courier",10,"bold"),width=5,height=2,relief=GROOVE,bd=10)
lM.grid(row=0,column=6,padx=5)

spaceFrame=Frame(keyboardFrame)
spaceFrame.grid(row=4,column=0)

spaceLabel=Label(spaceFrame,bg="Black",fg="White",font=("Courier",10,"bold"),width=40,height=2,bd=10,relief=GROOVE)
spaceLabel.grid(row=0,column=0)

labelNumbers=[l1,l2,l3,l4,l5,l6,l7,l8,l9,l0]
labelsAlphabets=[lA,lB,lC,lD,lE,lF,lG,lH,lI,lJ,lK,lL,lM,lN,lO,lP,lQ,lR,lS,lT,lU,lV,lW,lX,lY,lZ]
labelspace=[spaceLabel]

colors1=['Blue','Red','Green','Pink','Orange','Brown']
def changeBGColor(label):
        col = random.randint(0, len(colors1)-1)
        label.config(bg=(colors1[col]))
        label.after(200,lambda :label.config(bg='black'))
bindingNumbers=['1','2','3','4','5','6','7','8','9','0']
bindingSmallAlphabets=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
bindingCapitalAlphabets=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

for numbers in range(0,len(bindingNumbers)):
    root.bind(bindingNumbers[numbers],lambda event,label=labelNumbers[numbers]:changeBGColor(label))

for smallAlphabets in range(0,len(bindingSmallAlphabets)):
    root.bind(bindingSmallAlphabets[smallAlphabets],lambda event,label=labelsAlphabets[smallAlphabets]:changeBGColor(label))

for capitalAlphabets in range(0,len(bindingCapitalAlphabets)):
    root.bind(bindingCapitalAlphabets[capitalAlphabets],lambda event,label=labelsAlphabets[capitalAlphabets]:changeBGColor(label))

root.bind('<space>', lambda event: changeBGColor(labelspace[0]))

root.mainloop()
